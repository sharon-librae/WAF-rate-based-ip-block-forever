import boto3
import IPy
import json
import os

def lambda_handler(event, context):
    
    #define waf client
    waf_client = boto3.client('wafv2')
    
    #get ip blocked by rate_based limit rule
    waf_rate_ip_response = waf_client.get_rate_based_statement_managed_keys(
        Scope='CLOUDFRONT',
        WebACLName=str(os.environ.get('WebACL_Name')),
        WebACLId=str(os.environ.get('WebACL_Id')),
        RuleName=str(os.environ.get('Rule_Name'))
    )
    
    #blocked ipv4 addresses
    rate_block_ipv4 = waf_rate_ip_response['ManagedKeysIPV4']['Addresses']
    
    ##blocked ipv6 addresses
    #rate_block_ipv6 = waf_rate_ip_response['ManagedKeysIPV6']['Addresses']
    
    #get customer block ipv4 list
    customer_iplist_response_v4 = waf_client.get_ip_set(
        Name=str(os.environ.get('Customer_blocklist_Name_v4')),
        Scope='CLOUDFRONT',
        Id=str(os.environ.get('Customer_blocklist_id_v4'))
    )
    
    customer_iplist_v4 = customer_iplist_response_v4['IPSet']['Addresses']
    locktoken_v4 = customer_iplist_response_v4['LockToken']
    
    ##get customer block ipv6 list
    #customer_iplist_response_v6 = waf_client.get_ip_set(
    #    Name=str(os.environ.get('Customer_blocklist_Name_v6')),
    #    Scope='CLOUDFRONT',
    #    Id=str(os.environ.get('Customer_blocklist_id_v6'))
    #)
    
    #customer_iplist_v6 = customer_iplist_response_v6['IPSet']['Addresses']
    #locktoken_v6 = customer_iplist_response_v6['LockToken']
    
    #define whether ip in provided ip range    
    if rate_block_ipv4 != []:
        for ip in rate_block_ipv4:
            for ip_range in str(os.environ.get('ip_range_v4')).split(','):
                if ip in IPy.IP(ip_range):
                    customer_iplist_v4.append(ip_range)

        print(rate_block_ipv4)
        print(customer_iplist_v4)
        customer_iplist_v4_update = rate_block_ipv4 + customer_iplist_v4
        print(customer_iplist_v4_update)
        
        #update customer block ip
        updatev4_response = waf_client.update_ip_set(
            Name=str(os.environ.get('Customer_blocklist_Name_v4')),
            Scope='CLOUDFRONT',
            Id=str(os.environ.get('Customer_blocklist_id_v4')),
            Addresses=customer_iplist_v4_update,
            LockToken=locktoken_v4
        )        
    
    
    ##define whether ip in provided ip range
    #if rate_block_ipv6 != []:
    #    for ip in rate_block_ipv6:
    #        for ip_range in str(os.environ.get('ip_range_v6')).split(','):
    #            if ip in IPy.IP(ip_range):
    #                customer_iplist_v6.append(ip_range)
    #                
    #    customer_iplist_v6_update = rate_block_ipv6 + customer_iplist_v6
        
        ##update customer block ip
    #    updatev6_response = waf_client.update_ip_set(
    #        Name=str(os.environ.get('Customer_blocklist_Name_v6')),
    #        Scope='CLOUDFRONT',
    #        Id=str(os.environ.get('Customer_blocklist_id_v6')),
    #        Addresses=customer_iplist_v6_update,
    #        LockToken=locktoken_v6
    #    )
